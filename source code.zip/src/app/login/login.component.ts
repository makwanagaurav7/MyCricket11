import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, DoCheck {
  username = '';
  password;
  phoneNumber = '';
  showOtpBoxes = false;
  submitOtpDisabled = true;
  phoneNumberDisabled = false;
  sendOtpDisabled = true;
  pin1 = '';
  pin2 = '';
  pin3 = '';
  pin4 = '';
  constructor(private router:Router,
    private commonService: CommonService) { }

  ngOnInit(): void {
  }

  ngDoCheck() {
    if(this.pin1!== '' && this.pin2!== '' && this.pin3!== '' && this.pin4!== '') {
      this.submitOtpDisabled = false;
    } else {
      this.submitOtpDisabled = true;
    }
    if (this.phoneNumber.length === 10) {
      this.sendOtpDisabled = false;
    } else {
      this.sendOtpDisabled = true;
    }
  }

  proceedButtonClick() {
    if (this.username != '' && this.password != '') {
      this.commonService.username = this.username;
      this.router.navigate(['/dashboard']);
    }
  }

  sendOtpButtonClick() {
    if (this.phoneNumber.length === 10) {
      this.showOtpBoxes = true;
      this.phoneNumberDisabled = true;
    }
  }

  onKeypress(event) {
    if (event.keyCode >= 48 && event.keyCode <= 57) {
      return true;
    }
    return false;
  }

  submitOtpClick() {
    if (this.username === '') {
      this.commonService.username = 'Unknown';
    } else {
      this.commonService.username = this.username;
    }
    this.router.navigate(['/dashboard']);
  }
}
