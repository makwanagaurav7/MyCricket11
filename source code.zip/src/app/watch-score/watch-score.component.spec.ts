import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WatchScoreComponent } from './watch-score.component';

describe('WatchScoreComponent', () => {
  let component: WatchScoreComponent;
  let fixture: ComponentFixture<WatchScoreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WatchScoreComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WatchScoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
