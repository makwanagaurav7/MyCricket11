import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-watch-score',
  templateUrl: './watch-score.component.html',
  styleUrls: ['./watch-score.component.scss']
})
export class WatchScoreComponent implements OnInit {
  teamsArray = [];
  city;
  toss;
  venue;
  firstInnings;
  secondInnings;
  commentary = [];
  winnerOfTheMatch;
  outcome;

  constructor(private activatedRoute: ActivatedRoute, private commonService: CommonService) { }

  ngOnInit(): void {
    this.activatedRoute.params.subscribe((data) => {
      const jsonId = data.jsonId ? data.jsonId : '335982';
      this.commonService.getMatchJson(jsonId).subscribe((response: any) => {
        this.teamsArray = response.info.teams;
        this.city = response.info.city;
        this.toss = response.info.toss;
        this.venue = response.info.venue;
        this.firstInnings = response.innings[0]['1st innings'].deliveries;
        this.secondInnings = response.innings[1]['2nd innings'].deliveries;
        this.outcome = response.info.outcome;
        this.fetchCommentaries();
      }, (error) => {

      });
    });
  }

  fetchCommentaries() {
    let firstInningsCount = 0;
    let secondInningsCount = 0;
    setInterval(() => {
      let ballInfo = {};
      if (this.firstInnings.length !== firstInningsCount) {
        ballInfo = this.firstInnings[firstInningsCount++];
      } else if (this.secondInnings.length !== secondInningsCount) {
        ballInfo = this.secondInnings[secondInningsCount++];
      } else {
        if (this.outcome.by.runs) {
          this.winnerOfTheMatch = this.outcome.winner + " won by " + this.outcome.by.runs + " runs";
        } else {
          this.winnerOfTheMatch = this.outcome.winner + " won by " + this.outcome.by.wickets + " wickets";
        }
      }
      if (Object.keys(ballInfo).length > 0) {
        const ballNumber: any = Object.keys(ballInfo)[0];
        let additionnalInfo = '';
        if (ballInfo[ballNumber].wicket) {
          if (ballInfo[ballNumber].wicket.kind === 'caught') {
            additionnalInfo = ballInfo[ballNumber].wicket.player_out + ' is caught out by ' + ballInfo[ballNumber].wicket.fielders[0];
          } else if (ballInfo[ballNumber].wicket.kind === 'bowled') {
            additionnalInfo = ballInfo[ballNumber].wicket.player_out + ' is bowled out by ' + ballInfo[ballNumber].bowler;
          } else if (ballNumber.wicket.kind === 'run out') {
            additionnalInfo = ballInfo[ballNumber].wicket.player_out + ' is run out by ' + ballInfo[ballNumber].wicket.fielders[0] + ' and ' + ballInfo[ballNumber].wicket.fielders[1];
          }
        } else if (ballInfo[ballNumber].extras) {
          const key: any = Object.keys(ballInfo[ballNumber].extras);
          additionnalInfo = ballInfo[ballNumber].extras[key] + ' ' + key + ' extra runs by the ' + ballInfo[ballNumber].bowler;
        } else {
          additionnalInfo = ballInfo[ballNumber].runs.batsman + ' run get by ' + ballInfo[ballNumber].batsman;
        }
        this.commentary.splice(0, 0, {
          'ballNumber': ballNumber,
          'commentaryString': ballInfo[ballNumber].bowler + ' to ' + ballInfo[ballNumber].batsman + ', ' + additionnalInfo
        });
      }
    }, 5000);
  }
}
