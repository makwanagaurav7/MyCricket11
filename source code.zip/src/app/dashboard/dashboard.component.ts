import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  dashboardData;
  username;

  constructor(private commonService: CommonService, private router: Router) { }

  ngOnInit(): void {
    this.username = this.commonService.username;
    this.commonService.getTodayMatchJson().then((response: any) => {
      this.dashboardData = response;
    }, (error) => {
      console.log(error);
    });
  }

  joinNowClick(i) {
    alert('Fetch JSON: ' + this.commonService.jsonNumbers[i]);
  }

  watchScore(i) {
    this.router.navigate(['/watch-score/' + this.commonService.jsonNumbers[i]]);
  }
}
