import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  jsonNumbers = ['335982', '419152', '419121', '336015', '419107', '419113', '336000', '419125', '419149', '335990'];
  username = '';

  constructor(private httpClient: HttpClient) { }

  getMatchJson(jsonNumber) {
    return this.httpClient.get('http://localhost:4200/assets/jsons/' + jsonNumber + '.json');
  }

  getTodayMatchJson() {
    return new Promise((resolve, reject) => {
      const responseData = [];
      for (let i = 0; i < this.jsonNumbers.length; i++) {
        this.getMatchJson(this.jsonNumbers[i]).subscribe((response: any) => {
          responseData.push(response.info.teams);
          if (i === this.jsonNumbers.length - 1) {
            resolve(responseData);
          }
        }, (error) => {
          reject(error);
        });
      }
    });
  }
}
